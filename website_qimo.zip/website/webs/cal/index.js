$(document).ready(function () {
    $('#calendar').eCalendar();
});